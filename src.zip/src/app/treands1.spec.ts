import { Treands1 } from './treands1';

describe('Treands1', () => {
  it('should create an instance', () => {
    expect(new Treands1()).toBeTruthy();
  });
});
