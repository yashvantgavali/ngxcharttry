export class Treands1 {
    date ?: number;
    id ?: number;
}
